import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;

import javax.swing.*;

/**
 * The class <b>GameView</b> provides the current view of the entire Game. It extends
 * <b>JFrame</b> and lays out a matrix of <b>DotButton</b> (the actual game) and 
 * two instances of JButton. The action listener for the buttons is the controller.
 *
 * @author Guy-Vincent Jourdan, University of Ottawa
 */

public class GameView extends JFrame {

     private DotButton[][] board;
	 private GameModel gameModel;
	 private javax.swing.JLabel nbreOfStepsLabel;
	 private javax.swing.JLabel nbreOfMinesLabel;

    /**
     * Constructor used for initializing the Frame
     * 
     * @param gameModel
     *            the model of the game (already initialized)
     * @param gameController
     *            the controller
     */

    public GameView(GameModel gameModel, GameController gameController) {
		
		super("Minesweeper - The ITI1121 Edition");
		
		this.gameModel = gameModel;
		board = new DotButton[gameModel.getWidth()][gameModel.getHeigth()];
        
		setSize(28*gameModel.getWidth()+28, 28*gameModel.getHeigth()+105); //setSize(28*gameModel.getWidth()+28, 28*gameModel.getHeigth()+82);
		setLocationRelativeTo(null);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE); 
		setResizable(false);
		
		nbreOfStepsLabel = new JLabel();
		nbreOfMinesLabel = new JLabel();
		JPanel bottomPanel = new JPanel(); 
		bottomPanel.setLayout(new FlowLayout(FlowLayout.CENTER, 20, 10)); 
		nbreOfStepsLabel.setText("Number of Steps: " + gameModel.getNumberOfSteps());
		nbreOfMinesLabel.setText("Number of Remaining Mines: "+(gameModel.getMines()));
		JButton reset = new JButton("Reset");
		reset.addActionListener(gameController);
		JButton quit = new JButton("Quit"); 
		quit.addActionListener(gameController);
		bottomPanel.add(nbreOfStepsLabel);
		bottomPanel.add(nbreOfMinesLabel);
		bottomPanel.add(reset);
		bottomPanel.add(quit);
		add(bottomPanel, BorderLayout.SOUTH); 
		
		JPanel gameBoard = new JPanel();
		gameBoard.setLayout (new FlowLayout(FlowLayout.CENTER, 0, 0));
		
		for (int i = 0; i<gameModel.getHeigth(); i++){
			for (int j = 0; j<gameModel.getWidth(); j++){
				board[j][i] = new DotButton(j,i,11);
				board[j][i].addActionListener(gameController);
				board[j][i].addMouseListener(gameController);
				board[j][i].setPreferredSize(new Dimension(28,28));
				gameBoard.add(board[j][i]); 
			}
		}
		
		add(gameBoard);
	
		setVisible(true);

    }

    /**
     * update the status of the board's DotButton instances based 
     * on the current game model, then redraws the view
     */

    public void update(){
        
		nbreOfStepsLabel.setText("Number of Steps: " + gameModel.getNumberOfSteps());
		if((gameModel.getMines()-gameModel.getFlags())<0){
			nbreOfMinesLabel.setText("Number of Remaining Mines: 0");
		}
		nbreOfMinesLabel.setText("Number of Remaining Mines: "+(gameModel.getMines()-gameModel.getFlags()));
		boolean loss = false, win = false;
		
		for (int i = 0; i<gameModel.getHeigth(); i++){
			for (int j = 0; j<gameModel.getWidth(); j++){
				
				if (gameModel.isCovered(j,i)){
					board[j][i].setIconNumber(11);
				}
				if(gameModel.isFlagged(j,i)==true && gameModel.isCovered(j,i)==true){
					board[j][i].setIconNumber(12);
				}
				if (!gameModel.isCovered(j,i)){
					
					if (!gameModel.isMined(j,i)){
						board[j][i].setIconNumber(gameModel.getNeighbooringMines(j,i));
							
					} else { 
						loss = true;
					}
					
				} if (loss)	{
					
					for (int b = 0; b<gameModel.getHeigth(); b++){
						for (int k = 0; k<gameModel.getWidth(); k++){
							
							if (!gameModel.isMined(k,b)){
								board[k][b].setIconNumber(gameModel.getNeighbooringMines(k,b));
								
							} else {
								
								if (gameModel.hasBeenClicked(k,b)){
									board[k][b].setIconNumber(10);
								} else if (getIcon(k,b) == 11) {
									board[k][b].setIconNumber(9);
								}
							}
						}
					}
				}

				if(gameModel.isFinished()){
					for(int b = 0; b<gameModel.getHeigth(); b++){
						for(int k = 0; k<gameModel.getWidth(); k++){
							if(gameModel.isCovered(k,b)==true){
								board[k][b].setIconNumber(9);
							}
							
						}
					}
				}
			}
		}

    }

    /**
     * returns the icon value that must be used for a given dot 
     * in the game
     * 
     * @param i
     *            the x coordinate of the dot
     * @param j
     *            the y coordinate of the dot
     * @return the icon to use for the dot at location (i,j)
     */   
    private int getIcon(int i, int j){
        
		if (gameModel.isMined(i,j) && gameModel.hasBeenClicked(i,j)){
			return 10;
		} else if (gameModel.isMined(i,j) && !gameModel.hasBeenClicked(i,j)){
			return 11;
		} else {
			return gameModel.getNeighbooringMines(i,j); 
		}
    }


}
