import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.util.LinkedList;

import javax.swing.*;


/**
 * The class <b>GameController</b> is the controller of the game. It is a listener
 * of the view, and has a method <b>play</b> which computes the next
 * step of the game, and  updates model and view.
 *
 * @author Guy-Vincent Jourdan, University of Ottawa
 */


public class GameController implements ActionListener, MouseListener {

    private GameModel gameModel;
	private GameView gameView; 
	

    /**
     * Constructor used for initializing the controller. It creates the game's view 
     * and the game's model instances
     * 
     * @param width
     *            the width of the board on which the game will be played
     * @param height
     *            the height of the board on which the game will be played
     * @param numberOfMines
     *            the number of mines hidden in the board
     */
    public GameController(int width, int height, int numberOfMines) {

		gameModel = new GameModel(width, height, numberOfMines);
		gameView = new GameView(gameModel, this); 
		
    }


    /**
     * Callback used when the user clicks a button (reset or quit)
     *
     * @param e
     *            the ActionEvent
     */
    public void mouseClicked(MouseEvent e){
    	if(SwingUtilities.isRightMouseButton(e)){


			DotButton tile = (DotButton) e.getSource(); 
			
			int x = tile.getColumn();
			int y = tile.getRow();
			if(gameModel.isCovered(x,y)==true){
			if(gameModel.getFlags()<gameModel.getMines()){
			flag(x,y); 
		}
			else if((gameModel.getFlags()==gameModel.getMines()) && gameModel.isFlagged(x,y)==true){

				flag(x,y);
			}

    	}
    	
    }
}
    public void mousePressed(MouseEvent e){}
    public void mouseReleased(MouseEvent e){}
    public void mouseEntered(MouseEvent e){}
    public void mouseExited(MouseEvent e){}

    public void actionPerformed(ActionEvent e) {
        
		if (e.getSource() instanceof JButton){
			String buttonName = e.getActionCommand(); 
			if (buttonName.equals("Reset")){
				reset();
			}
		
			if (buttonName.equals("Quit")) { 
				System.exit(0);
			}	
		} if (e.getSource() instanceof DotButton) {

			DotButton tile = (DotButton) e.getSource(); 
			
			int x = tile.getColumn();
			int y = tile.getRow();

			if(gameModel.isFlagged(x,y) == false){
			play(x,y); 
		}

		}
			

    }

    /**
     * resets the game
     */
    private void reset(){

		gameModel.reset();
		gameView.update();

    }

    /**
     * <b>play</b> is the method called when the user clicks on a square.
     * If that square is not already clicked, then it applies the logic
     * of the game to uncover that square, and possibly end the game if
     * that square was mined, or possibly uncover some other squares. 
     * It then checks if the game
     * is finished, and if so, congratulates the player, showing the number of
     * moves, and gives to options: start a new game, or exit
     * @param width
     *            the selected column
     * @param heigth
     *            the selected line
     */

    private void play(int width, int heigth){

		if (!gameModel.hasBeenClicked(width,heigth)) {
			gameModel.click(width,heigth);
			gameModel.uncover(width, heigth); 
			gameModel.step();
			gameView.update();
			
			if (gameModel.isBlank(width,heigth) && !gameModel.isMined(width,heigth)){
				clearZone(gameModel.get(width,heigth));
				gameView.update();
			}
			
			if (gameModel.isMined(width,heigth)) {
				
				gameModel.uncoverAll(); 
						
				int result; 
				JOptionPane loss = new JOptionPane();
				Object[] options = {"Quit","Play Again"};
				result = loss.showOptionDialog(null, "Aouch, you lost in " + gameModel.getNumberOfSteps() + " steps! \nWould you like to play again?", "Boom!",JOptionPane.YES_NO_OPTION,JOptionPane.QUESTION_MESSAGE,null,options,options[1]);
				if (result==0) {
					System.exit(0);
				} else { 
					reset();
				}
					
				loss.setVisible(true);
				
			} else { 
			
				if (gameModel.isFinished()) {
					
					int result; 
					JOptionPane won = new JOptionPane();
					Object[] options2 = {"Quit","Play Again"};
					result = won.showOptionDialog(null, "Congratulations, you won in " + gameModel.getNumberOfSteps() + " steps! \nWould you like to play again?", "Won",JOptionPane.YES_NO_OPTION,JOptionPane.QUESTION_MESSAGE,null,options2,options2[1]);
					if (result==0) {
						System.exit(0);
					} else { 
						reset();
					}
					
					won.setVisible(true);
				}
			}
		}
    }

    private void flag(int width, int heigth){
    	if(gameModel.isFlagged(width, heigth)==false){
    		gameModel.setFlag(width, heigth);
    		
    		gameView.update();
    	}
    	else{
    		gameModel.unFlag(width, heigth);
    		
    		gameView.update();
    	}
    }

   /**
     * <b>clearZone</b> is the method that computes which new dots should be ``uncovered'' 
     * when a new square with no mine in its neighborood has been selected
     * @param initialDot
     *      the DotInfo object corresponding to the selected DotButton that
     * had zero neighbouring mines
     */
    private void clearZone(DotInfo initialDot) {

		Stack<DotInfo> blanks = new GenericArrayStack<DotInfo>(1000);
		blanks.push(initialDot);
		while (!blanks.isEmpty()){
			DotInfo blank = blanks.pop();
			
			for (int p = blank.getX() - 1; p <= blank.getX() + 1; p++){
						
                for (int q = blank.getY() - 1; q <= blank.getY() + 1; q++){
							
                    if (0 <= p && p < (gameModel.getWidth()) && 0 <= q && q < (gameModel.getHeigth())){
						if (p == blank.getX() && q == blank.getY() ) { 
							continue;
						} else { 
							if (gameModel.isCovered(p,q)){
								gameModel.uncover(p,q); 
								if(gameModel.isFlagged(p,q)){
									gameModel.unFlag(p,q);
								}
								if (gameModel.isBlank(p,q)) {
									blanks.push(gameModel.get(p,q));
								}
							}
						}
					}
				}
			}
		}
										
    }



}
