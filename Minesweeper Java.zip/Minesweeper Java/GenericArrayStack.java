public class GenericArrayStack<E> implements Stack<E> {
   
   private E[] elems;
   private int top; 

   // Constructor
    public GenericArrayStack( int capacity ) {
        
		elems = (E[]) new Object[capacity];
		top = -1; 

    }

    // Returns true if this ArrayStack is empty
    public boolean isEmpty() {
        
		if (top == -1) {
			return true;
		} else { 
			return false;
		}
    }

    public void push( E elem ) {
		
        int i = 0; 
		while (elems[i] != null){ 
			i += 1;
		}
		elems[i] = elem; 
		top += 1; 

    }
    public E pop() {
        
		int i = 0; 
		E temp; 
		
			while (elems[i] != null){ 
				i += 1;
			}
		temp = elems[i-1];
		elems[i-1] = null;
		top -= 1;
		return temp; 

    }

    public E peek() {
        
		int i = 0; 
			while (elems[i] != null){ 
				i += 1;
			}
		return elems[i-1];

    }
}
