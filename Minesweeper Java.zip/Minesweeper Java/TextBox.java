import java.util.Random;

public class TextBox{

	private static String s;
	private static final char[] alpha = "ABCDEFGHIJKLMNOPQRSTUVWXYZ".toCharArray();


	public TextBlock(String s){
		this.s = s;
	}
	
	public TextBlock(char[] in){
		s = new String(in);
	}

	public TextBlock(int size){
		Random gen = new Random();
		char[] chars = new char[size];
		for(int i= 0; i<size; i++){
			
			chars[i] = alpha[gen.nextInt(alpha.length)];
		}
		s = new String(chars);

	}

	public getText(){
		return(s);
	}

}